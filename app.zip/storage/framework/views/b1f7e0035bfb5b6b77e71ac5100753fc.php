<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=9">
    <meta name="description" content="Gambolthemes">
    <meta name="author" content="Gambolthemes">
    <title>Cursus - Downloaded Coursess video</title>

    <!-- Favicon Icon -->
    <link rel="icon" type="image/png" href="images/fav.png">

    <!-- Stylesheets -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,500' rel='stylesheet'>
    <link href='<?php echo e(asset('user/vendor/unicons-2.0.1/css/unicons.css')); ?>' rel='stylesheet'>
    <link href="<?php echo e(asset('user/css/vertical-responsive-menu.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/css/responsive.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/css/night-mode.css')); ?>" rel="stylesheet">

    <!-- Vendor Stylesheets -->
    <link href="<?php echo e(asset('user/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/vendor/OwlCarousel/assets/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/vendor/OwlCarousel/assets/owl.theme.default.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user/vendor/bootstrap-select/docs/docs/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('user/vendor/semantic/semantic.min.css')); ?>">

    <style>
        .html5-endscreen {
            cursor: default;
            overflow: hidden;
            z-index: 0;
            display: none !important;
        }

        .ytp-chrome-top-buttons {
            white-space: nowrap;
            visibility: hidden;
            display: none;
            opacity: 0px;
        }

        .ytp-impression-link-content {
            visibility: hidden;
            display: none;
            opacity: 0px;
        }

        .ytp-copylink-title {
            margin: auto;
            width: 36px;
            height: 36px;
            display: none !important;
            opacity: 0px;
            visibility: hidden;
        }

        .ytp-chrome-top {
            display: -webkit-flex;
            display: -webkit-box;
            display: flex;
            -webkit-flex-wrap: nowrap;
            flex-wrap: nowrap;
            -webkit-box-pack: end;
            -webkit-justify-content: flex-end;
            justify-content: flex-end;
            left: 12px;
            right: 12px;
            top: 0;
            z-index: 58;
            display: none;
        }
    </style>


</head>

<body>
    <!-- Header Start -->
    <div class="lecture-header d-flex">
        <div class="lecture-header-left d-flex">
            <a href="student_courses.html" class="back-to-curriculum" data-bs-toggle="tooltip" data-bs-title="go to purchased courses">
					<i class="fas fa-angle-left"></i>
				</a>
            <a href="javascript:;" class="nav-icon-list d-sm-block d-md-block d-lg-none"><i class="fas fa-list"></i></a>
        </div>
        <div class="lecture-header-right d-flex">
            
            
        </div>
    </div>
    <!-- Header End -->


    <!-- Body Start -->
    <div class="lecture-container-wrap d-flex">
        <div class="lecture-sidebar">
            <h4 class="p-4 lecture-sidebar-course-title">The Web Developer Bootcamp</h4>
            <div class="lecture-sidebar-curriculum-wrap">
                <div class="course-course-section">

                    <?php $__currentLoopData = $course_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="section-header pp-2 d-flex">
                            <span class="section-name flex-grow-1 ms-2 d-flex">
                                <strong class="flex-grow-1"><?php echo e($item->name); ?></strong>
                            </span>
                        </div>

                        <?php
                            $course_videos = App\Models\CourseVideo::where('course_module_id', $item->id)->where('status', 1)->get();
                        ?>
                        
                        <div class="course-section-body">
                            <?php $__currentLoopData = $course_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="sidebar-section-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                    <div class="section-item-title border-bottom">
                                        <a href="<?php echo e(route('user.course.videos', [$id, $row->video_slug])); ?>" class="pp-2 d-flex">
                                            <span class="lecture-status-icon pr-1">
                                                <i class="uil uil-file icon_142"></i>
                                            </span>
                                            <div class="title-container pl-2 flex-grow-1 d-flex">
                                                <span class="lecture-name flex-grow-1">
                                                    <?php echo e($row->video_title); ?> <small>(<?php echo e($row->video_timer); ?>)</small>
                                                </span>                                              
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


                
            </div>
        </div>

        <?php if( !empty($course_video_first->video_link) ): ?>
            <div class="lecture-container">
                <h2 class="lecture-title mb-4">A Note On Asking For Help</h2>
                <div class="lecture-content-inner mt-35">
                    <div class="lecture-content-inner-video">
                        <div class="video-responsive">
                                <?php echo $course_video_first->video_link; ?>

                                
                        </div>
                    </div>
                </div>
                
            </div>
        <?php endif; ?>

    </div>
    <!-- Body End -->

    <!-- Javascripts -->
    <script src="<?php echo e(asset('user/js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('user/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('user/vendor/OwlCarousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('user/vendor/bootstrap-select/docs/docs/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('user/vendor/semantic/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('user/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('user/js/night-mode.js')); ?>"></script>


</body>

</html><?php /**PATH D:\Real Client Project\course_management\resources\views/user/pages/course-module.blade.php ENDPATH**/ ?>