
<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('user.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- Header Start -->
       <?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header End -->


    <!-- Left Sidebar Start -->
       <?php echo $__env->make('user.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Left Sidebar End -->


    <!-- Body Start -->
    <div class="wrapper">
        <div class="sa4d25">
            <div class="container-fluid">
                
                <?php echo $__env->yieldContent('body-content'); ?>

            </div>
        </div>

        <?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- Body End -->

     <?php echo $__env->make('user.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\Real Client Project\course_management\resources\views/user/layout/master.blade.php ENDPATH**/ ?>