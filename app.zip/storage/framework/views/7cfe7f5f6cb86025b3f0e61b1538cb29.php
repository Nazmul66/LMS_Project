

<?php $__env->startPush('add-title'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('home', 'active'); ?>

<?php $__env->startSection('body-content'); ?>

<!-- header-area-start -->
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<section class="hero-section hero-4 overflow-hidden">
    <div class="shapes">
        <div class="shape shape-1"><img src="<?php echo e(asset('frontend/assets/img/shapes/hero-shape-16.png')); ?>" alt="shape"></div>
        <div class="shape shape-2"><img src="<?php echo e(asset('frontend/assets/img/shapes/hero-shape-17.png')); ?>" alt="shape"></div>
        <div class="shape shape-3"><img src="<?php echo e(asset('frontend/assets/img/shapes/hero-shape-18.png')); ?>" alt="shape"></div>
        <div class="shape shape-4"><img src="<?php echo e(asset('frontend/assets/img/shapes/hero-shape-19.png')); ?>" alt="shape"></div>
    </div>

    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
                <div class="hero-content hero-content-3 hero-content-4">
                    <div class="section-heading mb-20">
                        <h4 class="sub-heading wow fade-in-bottom" data-wow-delay="200ms"><span class="heading-icon"><i class="fa-sharp fa-solid fa-bolt"></i></span><?php echo e($banner->title); ?></h4>
                        <h2 class="section-title wow fade-in-bottom" data-wow-delay="400ms"><?php echo e($banner->subtitle); ?> </h2>
                    </div>
                    <h4 class="bottom-title"><?php echo e($banner->content); ?></h4>
                    
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="hero-img-wrap-2">
                    <div class="img-shape"><img src="<?php echo e(asset('frontend/assets/img/shapes/hero-img-shape-3.png')); ?>" alt="shape"></div>
                    <div class="img-shape-2"><img src="<?php echo e(asset('frontend/assets/img/shapes/hero-img-shape-4.png')); ?>" alt="shape"></div>
                    <div class="hero-img">
                        <img src="<?php echo e(asset($banner->image_path)); ?>" alt="hero">
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ./ hero-section -->

<section class="feature-section-4 pt-120 pb-120">
    <div class="container">
        <div class="section-heading text-center">
            <h4 class="sub-heading wow fade-in-bottom" data-wow-delay="200ms"><span class="heading-icon"><i class="fa-sharp fa-solid fa-bolt"></i></span><?php echo e($feature->title); ?></h4>
            <h2 class="section-title wow fade-in-bottom" data-wow-delay="400ms"><?php echo e($feature->subtitle); ?></h2>
        </div>
        <div class="row gy-lg-0 gy-4 justify-content-center">

            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="feature-card text-center wow fade-in-bottom" data-wow-delay="400ms">
                        <div class="icon"><img src="<?php echo e(asset($item->image)); ?>" alt="icon"></div>
                        <div class="content">
                            <h3 class="title"><?php echo e($item->title); ?></h3>
                            <p><?php echo e($item->content); ?></p>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            
        </div>
    </div>
</section>
<!-- ./ feature-section -->

<section class="about-section-4 pb-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
                <div class="faq-img-wrap about-img-wrap-4 wow fade-in-left" data-wow-delay="400ms">
                    <div class="faq-img">
                        <img src="<?php echo e(asset($aboutUs->image_path)); ?>" alt="faq">
                    </div>
                    
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div class="about-content-4">
                    <div class="section-heading mb-20">
                        <h4 class="sub-heading wow fade-in-bottom" data-wow-delay="200ms"><span class="heading-icon"><i class="fa-sharp fa-solid fa-bolt"></i></span><?php echo e($aboutUs->title); ?></h4>
                        <h2 class="section-title wow fade-in-bottom" data-wow-delay="400ms"><span><?php echo e($aboutUs->subtitle); ?></h2>
                    </div>
                    <p class="mb-30 wow fade-in-bottom" data-wow-delay="400ms"><?php echo e($aboutUs->content); ?></p>
                    
                    
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ./ course-section -->

<section class="feature-course pt-120 pb-120">
    <div class="container">
        <div class="course-top heading-space align-items-end">
            <div class="section-heading mb-0">
                <h4 class="sub-heading wow fade-in-bottom" data-wow-delay="200ms"><span class="heading-icon"><i class="fa-sharp fa-solid fa-bolt"></i></span>online courses</h4>
                <h2 class="section-title wow fade-in-bottom" data-wow-delay="400ms">Our courses​</h2>
            </div>
        </div>

        <div class="course-tab-content tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <div class="row gy-4 justify-content-center">

                    

                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="course-item">
                                <div class="course-thumb-wrap">
                                    <div class="course-thumb">
                                        <img src="<?php echo e(asset($item->image)); ?>" alt="course">
                                    </div>
                                </div>
                                <div class="course-content">
                                    
                                    <h3 class="title"><a href="<?php echo e(route('course-details', $item->id)); ?>"><?php echo e($item->title); ?></a></h3>
                                    <ul class="course-list">
                                        <li><i class="fa-light fa-file"></i>Lesson <?php echo e($item->lesson); ?></li>
                                        
                                        
                                    </ul>
                                    <div class="course-author-box">
                                        <div class="course-author">
                                            <div class="author-img">
                                                <img src="<?php echo e(asset($item->instructor_image)); ?>" alt="course">
                                            </div>
                                            <div class="author-info">
                                                <h4 class="name"><?php echo e($item->name); ?></h4>
                                                <span><?php echo e($item->designation); ?></span>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="bottom-content">
                                    <span class="price">$<?php echo e($item->price); ?></span>
                                    <a href="<?php echo e(route('course-details', $item->id)); ?>" class="course-btn">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    

                </div>
            </div>


            
        </div>
    </div>
</section>
<!-- ./ course-section -->


<!-- ./ features-event -->

<section class="testimonial-section-3 pt-120 pb-120">
    <div class="shapes">
        <div class="shape shape-1"><img src="<?php echo e(asset('frontend/assets/img/shapes/testi-shape-3.png')); ?>" alt="shape"></div>
        <div class="shape shape-2"><img src="<?php echo e(asset('frontend/assets/img/shapes/testi-shape-4.png')); ?>" alt="shape"></div>
    </div>
    <div class="container">
        <div class="row gy-xl-0 gy-5">
            <div class="col-xl-5 col-lg-12">
                <div class="testi-left-content white-content">
                    <div class="section-heading mb-20 white-content">
                        <h4 class="sub-heading wow fade-in-bottom" data-wow-delay="200ms"><span class="heading-icon"><i class="fa-sharp fa-solid fa-bolt"></i></span><?php echo e($testimonial->title); ?></h4>
                        <h2 class="section-title wow fade-in-bottom" data-wow-delay="400ms"><?php echo e($testimonial->subtitle); ?></h2>
                    </div>
                    
                </div>
            </div>
            <div class="col-xl-7 col-lg-12">
                <div class="testi-carousel-wrap-2">
                    <div class="testi-carousel-2 swiper">
                        <div class="swiper-wrapper">

                           <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="testi-item-3">
                                        <h3 class="title">Interactive Learning Experience</h3>
                                        <p><?php echo e($row->client_desc); ?></p>
                                        <div class="testi-author">
                                            <div class="testi-author-img">
                                                <img src="<?php echo e(asset($row->client_image)); ?>" alt="<?php echo e($row->client_name); ?>">
                                            </div>
                                            <h4 class="name"><?php echo e($row->client_name); ?> <span><?php echo e($row->client_designation); ?></span></h4>
                                        </div>
                                    </div>
                                </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="swiper-arrow">
                        <div class="swiper-nav swiper-next"><i class='bx bx-left-arrow-alt' style="font-size: 30px;"></i></div>
                        <div class="swiper-nav swiper-prev"><i class='bx bx-right-arrow-alt' style="font-size: 30px;"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ./ testimonial-section -->

<section class="team-section pt-120 pb-120">
    <div class="container">
        <div class="section-heading text-center">
            <h4 class="sub-heading wow fade-in-bottom" data-wow-delay="200ms"><span class="heading-icon"><i class="fa-sharp fa-solid fa-bolt"></i></span><?php echo e($instructor->title); ?></h4>
            <h2 class="section-title wow fade-in-bottom" data-wow-delay="400ms"><?php echo e($instructor->subtitle); ?></h2>
        </div>
        <div class="row gy-lg-0 gy-4 justify-content-center">

            <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6">
                    <div class="team-item-4 wow fade-in-bottom" data-wow-delay="300ms">
                        <div class="team-thumb">
                            <div class="overlay"></div>
                            <img src="<?php echo e(asset($item->image)); ?>" alt="team">
                        </div>
                        <div class="team-content">
                            <h3 class="title"><a href="javascript:void();"><?php echo e($item->name); ?></a></h3>
                            <span><?php echo e($item->designation); ?></span>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            
        </div>
    </div>
</section>
<!-- ./ team-section -->


<!-- ./ blog-section -->


<!-- ./ insta-section -->

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>