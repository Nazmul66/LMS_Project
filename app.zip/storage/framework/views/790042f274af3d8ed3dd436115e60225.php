<?php
    $setting = DB::table('settings')->first();
?>

<div id="preloader">
    <div class="spinner-logo">
        <?php if( !empty($setting) ): ?>
            <img src="<?php echo e(asset($setting->logo)); ?>" alt="logo">
        <?php else: ?>
            <img src="<?php echo e(asset('frontend/assets/img/favicon.png')); ?>" alt="logo">
        <?php endif; ?>
    </div>
    <div class="spinner"></div>
</div>
<!-- ./ preloader -->


<?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/preloader.blade.php ENDPATH**/ ?>