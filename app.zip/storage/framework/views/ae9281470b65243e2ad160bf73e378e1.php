

<?php $__env->startPush('add-title'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>



<?php $__env->startSection('body-content'); ?>

<!-- header-area-start -->
<?php echo $__env->make('frontend.include.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.include.breadcrumb', ['title' => 'Checkout'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ./ page-header -->

<section class="checkout-section pt-100 pb-100">
    <div class="container">
        
        
        <form action="<?php echo e(route('order')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="checkout-left">
                        <h3 class="form-header">Billing Details</h3>

                        <div class="checkout-form-wrap">
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item name">
                                        <h4 class="form-title">Full Name*</h4>
                                        <input type="text" id="name" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                                    </div>
                                </div>

                                
                            </div>

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item">
                                        <h4 class="form-title">Email Address*</h4>
                                        <input type="email" readonly id="email" value="<?php echo e(Auth::user()->email); ?>" name="email" class="form-control">
                                    </div>
                                </div>
                            </div>


                            

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item ">
                                        <h4 class="form-title">Street Address*</h4>
                                        <input type="text" id="address" name="address" class="form-control street-control" value="<?php echo e(old('address', Auth::user()->address ?? "")); ?>" placeholder="House number and street number">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item">
                                        <h4 class="form-title">Town / City*</h4>
                                        <input type="text" id="city" name="city" class="form-control" value="<?php echo e(old('city', Auth::user()->city ?? "")); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item">
                                        <h4 class="form-title">Zip Code*</h4>
                                        <input type="number" id="zip_code" name="zip_code" class="form-control" value="<?php echo e(old('zip_code', Auth::user()->zip_code ?? "")); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item">
                                        <h4 class="form-title">Phone*</h4>
                                        <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone', Auth::user()->phone ?? "")); ?>">
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12">
                    <div class="checkout-right">
                        <h3 class="form-header">Your Order</h3>
                        <div class="order-box">
                            <div class="order-items">
                                <div class="order-item item-1">
                                    <div class="order-left">
                                        <span class="product">Product</span>
                                    </div>
                                    <div class="order-right">
                                        <span class="price">Price</span>
                                    </div>
                                </div>

                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="order-item">
                                        <div class="order-left">
                                            <a href="<?php echo e(route('course-details', $row->id)); ?>" class="order-img">
                                                <img src="<?php echo e(asset($row->image)); ?>" alt="img">
                                            </a>
                                        </div>
                                        <div class="order-right">
                                            <div class="content">
                                                <span class="category"><?php echo e($row->cart_qty); ?> qty * $ <?php echo e(number_format($row->cart_price, 2)); ?></span>
                                                <h4 class="title"><?php echo e($row->title); ?></h4>
                                            </div>
                                            <span class="price">$<?php echo e(number_format($row->cart_qty * $row->cart_price, 2)); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                

                                <div class="order-item item-1">
                                    <div class="order-left">
                                        <span class="left-title">Subtotal</span>
                                    </div>
                                    <div class="order-right">
                                        <span class="right-title">$<?php echo e(number_format(getTotalCartAmount(), 2)); ?></span>
                                    </div>
                                </div>

                                

                                <div class="order-item item-1">
                                    <div class="order-left">
                                        <span class="left-title">Total Price:</span>
                                    </div>
                                    <div class="order-right">
                                        <span class="right-title title-2">$<?php echo e(number_format(getTotalCartAmount(), 2)); ?></span>
                                        <input type="hidden" name="total_amount" value="<?php echo e(getTotalCartAmount()); ?>">
                                    </div>
                                </div>
                            </div>

                            <input type="hidden" name="total_product" value="<?php echo e(getTotalCart()); ?>">

                            <div class="payment-option-wrap">
                                <div class="payment-option">
                                    

                                    

                                    <div class="shipping-option mb-5">
                                        <input id="free_shipping" type="radio" name="payment_method" value="cash_payment" required data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <label for="free_shipping" >Cash Payment</label>

                                        <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                 <div class="mb-3 mt-3">
                                                    <input type="text" class="form-control" name="payment_number" placeholder="Payment Number" required>
                                                 </div>

                                                <div class="mb-3">
                                                    <input type="text" class="form-control" name="transaction_id" placeholder="Transaction Id" required>
                                                </div>
                                            </div>
                                    </div>

                                    
                                </div>
                                
                                

                                <button class="ed-primary-btn order-btn">Place Your Order</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
<!-- ./ checkout-section -->

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/pages/checkout.blade.php ENDPATH**/ ?>