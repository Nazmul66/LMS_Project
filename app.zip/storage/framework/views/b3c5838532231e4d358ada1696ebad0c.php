

<?php $__env->startPush('add-title'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('cart', 'active'); ?>

<?php $__env->startSection('body-content'); ?>

<!-- header-area-start -->
<?php echo $__env->make('frontend.include.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.include.breadcrumb', ['title' => 'Cart Page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ./ page-header -->

<section class="cart-section pt-130 pb-130">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="table-content cart-table">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th class="product-remove"></th>
                                <th class="cart-product-name text-center">Products</th>
                                <th class="product-price"> Price</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-subtotal">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="product-remove">
                                        <a href="<?php echo e(route('cart.delete', $row->id)); ?>">
                                            <i class='bx bx-x' style="font-size: 24px;"></i>
                                        </a>
                                    </td>
                                    <td class="product-thumbnail">
                                        <a href="<?php echo e(route('course-details', $row->id)); ?>">
                                            <img src="<?php echo e(asset($row->image)); ?>" alt="img">
                                        </a>
                                        <div class="product-thumbnail">
                                            <h4 class="title"><?php echo e($row->title); ?></h4>
                                        </div>
                                    </td>
                                    <td class="product-price"><span class="amount">$<?php echo e(number_format($row->cart_price, 2)); ?></span></td>
                                    <td class="product-quantity">
                                        <div class="quantity__group">
                                            <input type="number" class="input-text qty text" name="quantity" readonly value="<?php echo e($row->cart_qty); ?>" min="1" max="100" step="1" autocomplete="off">
                                        </div>
                                    </td>
                                    <td class="product-subtotal"><span class="amount">$<?php echo e(number_format($row->cart_price * $row->cart_qty, 2)); ?></span></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">
                                        <div class="alert alert-danger mx-3" role="alert">
                                            There are no products in your cart.
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="5" class="text-center">
                                        <div class="checkout-proceed">
                                            <a href="<?php echo e(url('/')); ?>" class="ed-primary-btn checkout-btn">Go Back</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            
                        </tbody>
                    </table>
                </div>
                
            </div>
            <div class="col-lg-4">
            <div class="checkout-wrapper">
                <div class="checkout-top checkout-item item-1">
                    <h4 class="title">Cart Totals</h4>
                </div>
                <div class="checkout-top checkout-item">
                    <h4 class="title">Subtotal</h4>
                    <span class="price">$<?php echo e(number_format(getTotalCartAmount(), 2)); ?></span>
                </div>
                
                

                <div class="checkout-total checkout-item">
                    <h4 class="title">Total</h4>
                    <span>$<?php echo e(number_format(getTotalCartAmount(), 2)); ?></span>
                </div>
            </div>
            <div class="checkout-proceed">
                <a href="<?php echo e(route('checkout')); ?>" class="ed-primary-btn checkout-btn">Proceed to Checkout</a>
            </div>
            </div>
        </div>
    </div>
</section>
<!-- ./ cart-section -->


<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>checkout
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/pages/cart.blade.php ENDPATH**/ ?>