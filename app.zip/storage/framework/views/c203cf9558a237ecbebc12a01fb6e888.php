

<?php $__env->startPush('add-title'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contact', 'active'); ?>

<?php $__env->startSection('body-content'); ?>

<!-- header-area-start -->
<?php echo $__env->make('frontend.include.header2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.include.breadcrumb', ['title' => 'Contact Us'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ./ page-header -->

<section class="contact-section pt-120 pb-120">
    <div class="container">
        <div class="row gy-lg-0 gy-5">
            <div class="col-lg-7">
                <div class="blog-contact-form contact-form">
                    <h2 class="title mb-0">Leave A Reply</h2>
                    <p class="mb-30 mt-10">Fill-up The Form and Message us of your amazing question</p>
                    <div class="request-form">
                        <form action="<?php echo e(route('contact.post')); ?>" method="post" class="form-horizontal">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <div class="col-md-6">
                                    <div class="form-item">
                                        <input type="text" id="fullname" name="name" class="form-control" placeholder="Your Name">
                                        
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-item">
                                        <input type="email" id="email" name="email" class="form-control" placeholder="Your Email">
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    

                                    <div class="form-item">
                                       <input type="text" id="phone" name="phone" class="form-control" placeholder="Your Phone">
                                        
                                    </div> 

                                    <div class="form-item">
                                        <input type="text" id="subject" name="subject" class="form-control" placeholder="Subject">
                                         
                                     </div> 
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <div class="form-item message-item">
                                        <textarea id="message" name="message" cols="30" rows="5" class="form-control address" placeholder="Message"></textarea>
                                        <div class="icon"><i class="fa-light fa-messages"></i></div>
                                    </div>
                                </div>
                            </div>

                            <div class="submit-btn">
                                <button class="ed-primary-btn" type="submit">Submit Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="contact-content">
                    <div class="contact-top">
                        <h3 class="title">Office Information</h3>
                    </div>
                    <div class="contact-list">
                        <div class="list-item">
                            <div class="icon">
                                <i class="fa-sharp fa-solid fa-phone"></i>
                            </div>
                            <div class="content">
                                <h4 class="title">Phone Number & Email</h4>
                                <span><a href="tel:+65485965789"><?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?></a></span>
                                <span><a href="mailto:<?php echo e(getSetting()->email ? getSetting()->email : getSetting()->email_optional); ?>"><?php echo e(getSetting()->email ? getSetting()->email : getSetting()->email_optional); ?></a></span>
                            </div>
                        </div>
                        <div class="list-item">
                            <div class="icon">
                                <i class="fa-sharp fa-solid fa-location-dot"></i>
                            </div>
                            <div class="content">
                                <h4 class="title">Our Office Address</h4>
                                <p><?php echo e(getSetting()->address); ?></p>
                            </div>
                        </div>
                        <div class="list-item">
                            <div class="icon">
                                <i class="fa-sharp fa-solid fa-clock"></i>
                            </div>
                            <div class="content">
                                <h4 class="title">Official Work Time</h4>
                                <span><?php echo e(getSetting()->office_time_open); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ./ contact-section -->


<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>