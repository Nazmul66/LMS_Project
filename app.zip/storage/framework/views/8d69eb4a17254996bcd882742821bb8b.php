<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        @media (min-width: 768px) {
            .col-md-2 {
                flex: 0 0 auto;
                width: 12.666667%;
            }

            .col-md-10 {
                flex: 0 0 auto;
                width: 87.333333%;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
    </div>

    
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">

                    <form action="<?php echo e(route('admin.about_us.update', $row->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Title <span
                                            class="text-danger">*</span></label>
                                    <input name="title" id="title" placeholder="Write title" type="text"
                                        class="form-control" value="<?php echo e(old('title', $row->title)); ?>">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="subtitle" class="form-label">Subtitle <span
                                            class="text-danger">*</span></label>
                                    <input name="subtitle" id="subtitle" placeholder="Write subtitle" type="text"
                                        class="form-control" value="<?php echo e(old('subtitle', $row->subtitle)); ?>">
                                </div>
                            </div>
                        </div>


                        

                        <div class="row">
                            
                            
                            
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label for="question" class="form-label">Image <span
                                        class="text-danger">* Recommended (
                                        1050px X 460px )</span></label>
                                <input id="formFile" type="file" name="image_path"
                                    accept=".jpg, .jpeg, .png, .webp" class="form-control form-control">

                                <a href="<?php echo e(asset($row->image_path)); ?>" target="_blank" rel="noopener noreferrer">
                                    <img id="previewImage" src="<?php echo e(asset($row->image_path)); ?>" class="mt-3 mb-3" alt="Preview"
                                            style="display: block; width: 200px; height: 80px;">
                                </a>
                            </div>

                            

                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="contents" class="form-label">Description <span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" name="content" id="contents" placeholder="Write description here...."
                                        rows="8"><?php echo e(old('content', $row->content)); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div>
                            <button type="submit" class="btn btn-info waves-effect waves-light w-md">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/12.3.1/classic/ckeditor.js"></script>
    <script>
        $(document).ready(function() {
            let jReq;
            ClassicEditor
                .create(document.querySelector('#content'))
                .then(newEditor => {
                    jReq = newEditor;
                })
                .catch(error => {
                    console.error(error);
                });
        });
        document.getElementById('formFile').addEventListener('change', function(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('previewImage');

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/about_us/index.blade.php ENDPATH**/ ?>