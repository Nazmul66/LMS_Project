<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('course', 'mm-active'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
        <a href="<?php echo e(route('admin.course.index')); ?>" class="btn btn-primary waves-effect waves-light">Back</a>
    </div>

    
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">

                    <form action="<?php echo e(route('admin.course_module.update', $courseModule->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">  

                            <input type="hidden" name="course_id" value="<?php echo e($course_id); ?>">

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name <span
                                            class="text-danger">*</span></label>

                                    <input name="name" id="name" class="form-control"
                                        placeholder="Write here....." type="text"
                                        value="<?php echo e(old('name', $courseModule->name)); ?>">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status <span
                                            class="text-danger">*</span></label>
                                    <select name="status" class="form-control form-select">
                                        <option value="1" <?php if( $courseModule->status == 1 ): ?> selected <?php endif; ?>>Active</option>
                                        <option value="0" <?php if( $courseModule->status == 0 ): ?> selected <?php endif; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div>
                            <button type="submit" class="btn btn-info waves-effect waves-light w-md">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('script'); ?>

    <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/course_module/edit.blade.php ENDPATH**/ ?>