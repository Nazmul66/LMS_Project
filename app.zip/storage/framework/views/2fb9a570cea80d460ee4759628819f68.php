

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('dashboard', 'active'); ?>

<?php $__env->startSection('body-content'); ?>


<div class="_215b01">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="section3125">
                    <div class="row justify-content-center">
                        <div class="col-xl-4 col-lg-5 col-md-6">
                            <div class="preview_video">
                                <a href="<?php echo e(route('user.course.module', $course->id)); ?>" class="fcrse_img" data-bs-toggle="modal" data-bs-target="#videoModal">
                                    <img src="<?php echo e(asset($course->image)); ?>" alt="">
                                    <div class="course-overlay">
                                        
                                        <span class="play_btn1"><i class='bx bx-play'></i></span>
                                        <span class="_215b02">Preview this course</span>
                                    </div>
                                </a>
                            </div>

                            
                        </div>
                        <div class="col-xl-8 col-lg-7 col-md-6">
                            <div class="_215b03">
                                <h2><?php echo e($course->title); ?></h2>
                                
                            </div>

                            

                            

                            
                            <div class="_215b06">
                                <div class="_215b07">
                                    <span><i class='bx bx-cart'></i></span> $<?php echo e($course->price); ?>

                                </div>
                            </div>

                            <div class="_215b05">
                                Last updated <?php echo e(date('d/Y', strtotime($course->updated_at))); ?>

                            </div>

                            <ul class="_215b31">
                                <li>
                                    <button class="btn_adcart">
                                        <a href="<?php echo e(route('user.course.module', $course->id)); ?>" style="color: #FFF;">Preview This Course</a>
                                    </button>
                                </li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="_215b15 _byt1458">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="user_dt5">
                    <div class="user_dt_left">
                        <div class="live_user_dt">
                            <div class="user_img5">
                                <a href="#"><img src="<?php echo e(asset($course->instructor_image)); ?>" alt=""></a>
                            </div>
                            <div class="user_cntnt">
                                <a href="#" class="_df7852"><?php echo e($course->name); ?></a>
                                <span ><?php echo e($course->designation); ?></span>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="course_tabs">
                    <nav>
                        <div class="nav nav-tabs tab_crse justify-content-center" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-about-tab" data-bs-toggle="tab" href="#nav-about" role="tab" aria-selected="true">About</a>
                            <a class="nav-item nav-link" id="nav-courses-tab" data-bs-toggle="tab" href="#nav-courses" role="tab" aria-selected="false">Courses Content</a>
                            
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="_215b17">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="course_tab_content">
                    <div class="tab-content" id="nav-tabContent">

                        
                        <div class="tab-pane fade show active" id="nav-about" role="tabpanel">
                            <div class="_htg451">
                                <div class="_htg452">

                                    <?php echo $course->description; ?>


                                    
                                </div>
                            </div>
                        </div>


                        
                        <div class="tab-pane fade" id="nav-courses" role="tabpanel">
                            <div class="crse_content">
                                <h3>Course content</h3>
                                  <?php $__currentLoopData = $course_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $course_videos = App\Models\CourseVideo::where('course_module_id', $item->id)->where('status', 1)->get();
                                        ?>

                                    <a href="javascript:void(0)" class="accordion-header">
                                        <div class="section-header-left">
                                            <span class="section-title-wrapper">
                                                <i class='bx bx-slideshow'></i>
                                                <span class="section-title-text"><?php echo e($item->name); ?></span>
                                            </span>
                                        </div>
                                        <div class="section-header-right">
                                            <span class="num-items-in-section"><?php echo e($course_videos->count()); ?> lectures</span>
                                            <span class="section-header-length">Duration</span>
                                        </div>
                                    </a>

                                        <?php $__currentLoopData = $course_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="ui-accordion-content">
                                                <div class="lecture-container">
                                                    <div class="left-content">
                                                        <i class='bx bx-play-circle'></i>
                                                        <div class="top">
                                                            <div class="title"><?php echo e($row->video_title); ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="details">
                                                        <span class="content-summary"><?php echo e($row->video_timer); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/user/pages/course-details.blade.php ENDPATH**/ ?>