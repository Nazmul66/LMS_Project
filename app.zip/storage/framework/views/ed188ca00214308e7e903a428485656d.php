

<?php $__env->startPush('add-css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body-content'); ?>

<div class="row">
    <div class="col-lg-12">
        <h2 class="st_title">My Courses</h2>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="_14d25">
            <div class="row">

                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4">
                        <div class="fcrse_1 mt-30">
                            <a href="<?php echo e(route('user.course.details', $row->id)); ?>" class="fcrse_img">
                                <img src="<?php echo e(asset($row->image)); ?>" alt="">
                                <div class="course-overlay">
                                    
                                    
                                    <span class="play_btn1"><i class='bx bx-play' ></i></span>
                                    <div class="crse_timer">
                                        <?php echo e($row->duration); ?>

                                    </div>
                                </div>
                            </a>
                            <div class="fcrse_content">
                                <div class="vdtodt">
                                    
                                    <span class="vdt14"><?php echo e($row->created_at->diffForHumans()); ?></span>
                                </div>
                                <a href="<?php echo e(route('user.course.details', $row->id)); ?>" class="crse14s"><?php echo e($row->title); ?></a>
                                
                                <div class="auth1lnkprce">
                                    <p class="cr1fot">By <span><?php echo e($row->name); ?></span></p>
                                    <div class="prce142">$<?php echo e($row->price); ?></div>
                                    <button class="shrt-cart-btn" title="cart"><i class='bx bx-cart'></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

                

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/user/pages/course.blade.php ENDPATH**/ ?>