<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> ©
                
            </div>
            <div class="col-sm-6">
                
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Real Client Project\course_management\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>