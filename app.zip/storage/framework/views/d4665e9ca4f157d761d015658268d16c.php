<?php
    $courses = App\Models\Course::where('status', 1)->orderBy('id','DESC')->limit(2)->get();
?>

<footer class="footer-section pt-120" data-background="<?php echo e(asset('frontend/assets/img/bg-img/footer-bg.png')); ?>">
    <div class="footer-top-wrap">
        <div class="container">
            

            <div class="row footer-wrap">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-widget">
                        <h3 class="widget-header">Get in touch!</h3>
                        <p class="mb-30"><?php echo e(getSetting()->address ?? ""); ?></p>
                        <div class="footer-contact">
                            <span class="number">
                                <i class='bx bx-phone-call' style="font-size: 24px;"></i><a href="tel:<?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?>"><?php echo e(getSetting()->phone ? getSetting()->phone : getSetting()->phone_optional); ?></a>
                            </span>
                            <a href="mailto:info@company.com" class="mail d-block">info@company.com</a>
                        </div>
                        <ul class="footer-social">
                            <?php if( !empty(getSetting()->facebook_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->facebook_url)); ?>">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if( !empty(getSetting()->instagram_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->instagram_url)); ?>">
                                        <i class="fab fa-instagram"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if( !empty(getSetting()->twitter_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->twitter_url)); ?>">
                                        <i class="fa-brands fa-x-twitter"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if( !empty(getSetting()->linkedin_url) ): ?>
                                <li>
                                    <a href="<?php echo e(asset(getSetting()->linkedin_url)); ?>">
                                        <i class="fa-brands fa-linkedin-in"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="footer-widget widget-2">
                        <h3 class="widget-header">Course Info</h3>
                        
                                <ul class="footer-list">
                                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                    <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                    <?php if( !Auth::check() ): ?>
                                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                    <?php endif; ?>
                                </ul>
                            

                            
                        
                        
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="footer-widget">
                        <h3 class="widget-header">Recent Post</h3>

                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sidebar-post mb-20">
                                <img src="<?php echo e(asset($row->image)); ?>" alt="post">
                                <div class="post-content">
                                    <h3 class="title">
                                        <a href="<?php echo e(route('course-details', $row->id)); ?>"><?php echo e(Str::substr($row->title, 0, 60)); ?>...</a>
                                    </h3>
                                    <ul class="post-meta">
                                        <li><i class='bx bx-calendar' style="font-size: 20px;"></i><?php echo e(date('M d, Y', strtotime($row->created_at))); ?></li>
                                    </ul>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area">
        <div class="container">
            <div class="copyright-content">
                <p>Copyright © <u><a href="<?php echo e(url('/')); ?>"><?php echo e(getSetting()->copyright); ?></a></u>. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/footer.blade.php ENDPATH**/ ?>