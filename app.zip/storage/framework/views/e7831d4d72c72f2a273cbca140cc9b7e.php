<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins/feature.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">

                    <form action="<?php echo e(route('admin.testimonials.section.update', $section->id)); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="title" class="form-label">Section Title <span
                                                class="text-danger">*</span></label>
                                        <input name="title" id="title" placeholder="Write service title" type="text"
                                            class="form-control" value="<?php echo e(old('title', $section->title)); ?>">
                                    </div>
                                </div>
    
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="subtitle" class="form-label">Section Subtitle <span
                                                class="text-danger">*</span></label>
                                        <input name="subtitle" id="subtitle" placeholder="Write service subtitle" type="text"
                                            class="form-control" value="<?php echo e(old('subtitle', $section->subtitle)); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="video_link" class="form-label">Is Active <span
                                            class="text-danger">*</span></label>
                                    <select name="is_active" id="is_active" class="form-control form-select">
                                        <option value="1" <?php echo e($section->is_active == 1 ? 'selected' : ''); ?>>Yes</option>
                                        <option value="0" <?php echo e($section->is_active == 0 ? 'selected' : ''); ?>>No</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div>
                            <button type="submit" class="btn btn-info waves-effect waves-light w-md">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h4 class="mb-sm-0 font-size-18">Testimonial List</h4>
                <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-primary waves-effect waves-light">Add New</a>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered mb-0 table-hover" id="datatables">
                    <thead>
                        <tr>
                            <th>#SL.</th>
                            <th>Image</th>
                            <th>Client Name</th>
                            <th>Client Designation</th>
                            <th>Rating</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key + 1); ?></th>
                                <td class="text-center">
                                    <a href="<?php echo e(asset($row->client_image)); ?>" target="__blank">
                                        <img src="<?php echo e(asset($row->client_image)); ?>" alt="icon"
                                            style="width: 70px; height: 70px; object-fit: contain;">
                                    </a>
                                </td>
                                <td>
                                    <span class="text-primary"><?php echo e($row->client_name); ?></span>
                                </td>
                                <td><?php echo e($row->client_designation); ?></td>
                                <td class="text-warning">
                                    <?php echo e($row->rating); ?> Star
                                </td>
                                <td>
                                    <?php if($row->status == 1): ?>
                                        <span class="btn btn-success">Active</span>
                                    <?php else: ?>
                                        <span class="btn btn-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-primary waves-effect waves-light dropdown-toggle"
                                            type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Actions
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <button class="dropdown-item" data-bs-toggle="modal"
                                                    data-bs-target="#view_modal<?php echo e($row->id); ?>"
                                                    style="font-size: 16px;"><i
                                                        class="fas fa-eye"></i> View</button>
                                            </li>

                                            <li>
                                                <a href="<?php echo e(route('admin.testimonials.edit', $row->id)); ?>"
                                                    class="dropdown-item" style="font-size: 16px;"><i
                                                        class='bx bxs-edit text-info me-2'></i>Edit</a>
                                            </li>

                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(route('admin.testimonials.delete', $row->id)); ?>"
                                                    style="font-size: 16px;" id="deleteData"><i
                                                        class='bx bxs-trash text-danger'></i> Delete</a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            <!-- View Modal -->
                            <div class="modal fade" id="view_modal<?php echo e($row->id); ?>" tabindex="-1"
                                aria-labelledby="edit_lLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">View Testimonial List
                                            </h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>

                                        <div class="modal-body">
                                            <div class="view_modal_content">
                                                <label>Image : </label>
                                                <a href="<?php echo e(asset($row->client_image)); ?>" target="__blank">
                                                    <img src="<?php echo e(asset($row->client_image)); ?>" alt="icon"
                                                        style="width: 70px; height: 70px; object-fit: contain;">
                                                </a>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Client Name : </label>
                                                <span class="text-primary"><?php echo e($row->client_name); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Client Designation : </label>
                                                <span><?php echo e($row->client_designation); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Rating : </label>
                                                <span class="text-warning"><?php echo e($row->rating); ?> Star</span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Description : </label>
                                                <span class="text-dark"><?php echo $row->client_desc; ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Status : </label>
                                                <?php if($row->status == 1): ?>
                                                    <span class="text-success">Active</span>
                                                <?php else: ?>
                                                    <span class="text-danger">Inactive</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/12.3.1/classic/ckeditor.js"></script>
    <script>
        $(document).ready(function() {
            let jReq;
            ClassicEditor
                .create(document.querySelector('#content'))
                .then(newEditor => {
                    jReq = newEditor;
                    const editorElement = newEditor.ui.view.editable.element;
                    editorElement.style.maxHeight = '90px';
                    editorElement.style.overflowY = 'auto';
                })
                .catch(error => {
                    console.error(error);
                });
        });
    </script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
    <script>
        let table = new DataTable('#datatables', {
            responsive: true
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/testimonials/index.blade.php ENDPATH**/ ?>