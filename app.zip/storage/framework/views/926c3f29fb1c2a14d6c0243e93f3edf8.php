<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
   <?php echo $__env->make('frontend.include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <!-- preloader-area-start -->
    <?php echo $__env->make('frontend.include.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Body-content-area-start -->
           <?php echo $__env->yieldContent('body-content'); ?>
        <!-- Body-content-area-start -->

    
    <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ./ footer-section -->

    
    <?php echo $__env->make('frontend.include.scroll_to_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--scrollup-->

    <!-- JS here -->
    <?php echo $__env->make('frontend.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>