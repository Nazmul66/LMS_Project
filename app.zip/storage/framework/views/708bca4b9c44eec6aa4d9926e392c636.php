<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('course', 'mm-active'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
        <a href="<?php echo e(route('admin.course.index')); ?>" class="btn btn-primary waves-effect waves-light">Back</a>
    </div>


    
    <div class="card">
        <div class="card-header">
            <h3><?php echo e($course->title); ?></h3>
        </div>
        <div class="card-body">
            
            <p><strong>Duration:</strong> <?php echo e($course->duration); ?> Days</p>
            

            
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('script'); ?>

    <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/course/view.blade.php ENDPATH**/ ?>