<script src="<?php echo e(asset('user/js/jquery-3.7.1.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('user/vendor/OwlCarousel/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('user/vendor/bootstrap-select/docs/docs/dist/js/bootstrap-select.js')); ?>"></script>

<!-- toaster Js plugins  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script src="<?php echo e(asset('user/vendor/semantic/semantic.min.js')); ?>"></script>
<script src="<?php echo e(asset('user/js/custom1.js')); ?>"></script>
<script src="<?php echo e(asset('user/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('user/js/night-mode.js')); ?>"></script>


<?php echo $__env->yieldPushContent('add-js'); ?>

<?php echo Toastr::message(); ?>


<script>
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error("<?php echo $error; ?>");
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script><?php /**PATH D:\Real Client Project\course_management\resources\views/user/include/js.blade.php ENDPATH**/ ?>