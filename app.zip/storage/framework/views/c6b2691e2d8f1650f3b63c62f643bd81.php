<nav class="vertical_nav">
    <div class="left_section menu_left" id="js-menu">
        <div class="left_section">
            <ul>
                <li class="menu--item">
                    <a href="<?php echo e(route('user.dashboard')); ?>" class="menu--link <?php echo $__env->yieldContent('dashboard'); ?>" title="Dashboard">
                        <i class='bx bxs-dashboard menu--icon'></i>
                        <span class="menu--label">Dashboard</span>
                    </a>
                </li>

                <li class="menu--item">
                    <a href="<?php echo e(route('user.order')); ?>" class="menu--link <?php echo $__env->yieldContent('order'); ?>" title="Courses">
                        <i class='bx bxs-bar-chart-alt-2 menu--icon'></i>
                        <span class="menu--label">Order</span>
                    </a>
                </li>

                <li class="menu--item">
                    <a href="<?php echo e(route('user.user.profile')); ?>" class="menu--link <?php echo $__env->yieldContent('user-profile'); ?>" title="Courses">
                        <i class='bx bx-user-circle menu--icon'></i>
                        <span class="menu--label">My Profile</span>
                    </a>
                </li>

                <li class="menu--item">
                    <a href="<?php echo e(url('/')); ?>" class="menu--link" title="Homepage">
                        <i class='bx bx-door-open menu--icon'></i>
                        <span class="menu--label">Go Homepage</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\Real Client Project\course_management\resources\views/user/include/sidebar.blade.php ENDPATH**/ ?>