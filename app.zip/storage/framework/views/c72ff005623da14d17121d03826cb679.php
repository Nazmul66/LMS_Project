<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('course', 'mm-active'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
        <a href="<?php echo e(route('admin.course_video.index', $course_module_id)); ?>" class="btn btn-primary waves-effect waves-light">Back</a>
    </div>

    
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">

                    <form action="<?php echo e(route('admin.course_video.update', $course_video->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="course_module_id" value="<?php echo e($course_module_id); ?>">

                        <div class="row align-items-end">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="video_title" class="form-label">Video Title <span
                                            class="text-danger">*</span></label>
                                    <input name="video_title" id="video_title" class="form-control"
                                        placeholder="Write here....." type="text"
                                        value="<?php echo e(old('video_title', $course_video->video_title)); ?>">
                                </div>
                            </div>

                            
                        </div>

                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="status" class="form-label">Status <span
                                        class="text-danger">*</span></label>
                                <select name="status" class="form-control form-select">
                                    <option value="1" <?php if( $course_video->status == 1 ): ?> selected <?php endif; ?>>Active</option>
                                    <option value="0" <?php if( $course_video->status == 0 ): ?> selected <?php endif; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="video_link" class="form-label">Video Code <span
                                        class="text-danger">*</span></label>

                                <input name="video_link" id="video_link" class="form-control"
                                placeholder="Write here....." type="text"
                                value="<?php echo e(old('video_link', $course_video->video_link)); ?>">

                                
                            </div>
                        </div>

                        <div class="video_show">
                              <iframe width="640" height="360"
                                src="https://www.youtube.com/embed/<?php echo e($course_video->video_link); ?>?modestbranding=1&rel=0&showinfo=0&iv_load_policy=3" frameborder="0"
                                allow="autoplay; encrypted-media" allowfullscreen>
                            </iframe>
                        </div>

                        <div>
                            <button type="submit" class="btn btn-info waves-effect waves-light w-md">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('script'); ?>
        <script src="https://cdn.ckeditor.com/ckeditor5/41.1.0/classic/ckeditor.js"></script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/course_video/edit.blade.php ENDPATH**/ ?>