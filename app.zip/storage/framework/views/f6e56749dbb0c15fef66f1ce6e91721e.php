

<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('order', 'mm-active'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />

    <style>
        .dt-layout-cell{
            overflow-x: auto !important;
        }
        /* .duplicate_data{

        }
        .duplicate_data.active td{
             background: #ff000038;
        } */
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0 font-size-18"><?php echo e($title); ?></h4>
    </div>


    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered mb-0 table-hover" id="datatables">
                    <thead>
                        <tr>
                            <th>#SL.</th>
                            <th>Transaction Id</th>
                            <th>Payment Number</th>
                            <th>Course Name</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Total Product</th>
                            <th>Total Amount</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        

                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            
                            <tr>
                                <td scope="row"><?php echo e($key + 1); ?></td>
                                <td ><?php echo e($row->transaction_id); ?></td>
                                <td>
                                    <span >
                                        <?php echo e($row->payment_number); ?>

                                    </span>
                                </td>
                                <td>
                                    <span >
                                        <?php echo e($row->course_title); ?>

                                    </span>
                                </td>
                                <td>
                                    <span >
                                        <?php echo e($row->name); ?>

                                    </span>
                                </td>
                                <td>
                                    <a href="mailto:<?php echo e($row->email); ?>"><?php echo e($row->email); ?></a>
                                </td>
                                <td>
                                    <a href="tel:<?php echo e($row->phone); ?>" ><?php echo e($row->phone); ?></a>
                                </td>
                                <td>
                                    <span class="text-dark"><?php echo e($row->total_product); ?></span>
                                </td>
                                <td>
                                    <span class="text-dark">$<?php echo e($row->total_amount); ?></span>
                                </td>
                                <td>
                                    <span class="text-dark"><?php echo e($row->payment_method); ?></span>
                                </td>
                                <td>
                                    <?php if( $row->status === 1 ): ?>
                                        <span class="text-success">Paid</span>
                                    <?php elseif( $row->status === 2 ): ?>
                                        <span class="text-warning">Pending</span>
                                    <?php else: ?>
                                        <span class="text-danger">Cancelled</span>
                                    <?php endif; ?>

                                </td>
                                <td>
                                    <span class="text-dark"
                                        ><?php echo e(date('Y-m-d', strtotime($row->created_at))); ?></span>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-primary waves-effect waves-light dropdown-toggle" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false">
                                            Actions
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <button class="dropdown-item" data-bs-toggle="modal"
                                                    data-bs-target="#view_modal<?php echo e($row->id); ?>" style="font-size: 16px;"><i
                                                        class="fas fa-eye"></i> View</button>
                                            </li>

                                            <?php if($row->status == 1): ?> <!-- Status 1: Paid -->
                                                <li>
                                                    <a href="<?php echo e(route('admin.order.pending.update', $row->order_id)); ?>" class="dropdown-item" style="font-size: 16px;">
                                                        <span class="text-warning">
                                                            <i class="fas fa-exclamation-circle"></i> Pending
                                                        </span>
                                                    </a>
                                                </li>

                                                <li>
                                                    <a href="<?php echo e(route('admin.order.cancel.update', $row->order_id)); ?>" class="dropdown-item" style="font-size: 16px;">
                                                        <span class="text-danger">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </span>
                                                    </a>
                                                </li>
                                                
                                            <?php elseif($row->status == 2): ?> <!-- Status 2: Pending -->
                                                <li>
                                                    <a href="<?php echo e(route('admin.order.update', $row->order_id)); ?>" class="dropdown-item" style="font-size: 16px;">
                                                        <span class="text-success">
                                                            <i class="fas fa-check-circle"></i> Paid
                                                        </span>
                                                    </a>
                                                </li>

                                                <li>
                                                    <a href="<?php echo e(route('admin.order.cancel.update', $row->order_id)); ?>" class="dropdown-item" style="font-size: 16px;">
                                                        <span class="text-danger">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </span>
                                                    </a>
                                                </li>

                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                            <!-- View Modal -->
                            <div class="modal fade" id="view_modal<?php echo e($row->id); ?>" tabindex="-1"
                                aria-labelledby="edit_lLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">View Order List</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>

                                        <div class="modal-body">
                                            <div class="view_modal_content">
                                                <label>Name : </label>
                                                <span class="text-dark"><?php echo e($row->name); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Email : </label>
                                                <a href="mailto:<?php echo e($row->email); ?>" class="text-info"><?php echo e($row->email); ?></a>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Phone : </label>
                                                <a href="tel:<?php echo e($row->phone); ?>" class="text-info"><?php echo e($row->phone); ?></a>
                                            </div>

                                            <div class="message_content">
                                                <label>Total Product : </label>
                                                <span class="text-dark"><?php echo e($row->total_product); ?></span>
                                            </div>

                                            <div class="message_content">
                                                <label>Total Amount : </label>
                                                <span class="text-dark">$<?php echo e($row->total_amount); ?></span>
                                            </div>

                                            <div class="message_content">
                                                <label>Payment Method : </label>
                                                <span class="text-dark"><?php echo e($row->payment_method); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Date : </label>
                                                <span class="text-dark"><?php echo e(date('Y-m-d', strtotime($row->created_at))); ?></span>
                                            </div>

                                            <div class="view_modal_content">
                                                <label>Status : </label>
                                                <?php if($row->status == 1): ?>
                                                    <span class="text-success">Active</span>
                                                <?php else: ?>
                                                    <span class="text-danger">Inactive</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>

    <script>
        let table = new DataTable('#datatables', {
            responsive: true
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/admin/pages/order/index.blade.php ENDPATH**/ ?>