<header class="header clearfix">
    

    <div class="main_logo" id="logo">
        <a href="<?php echo e(route('user.dashboard')); ?>"><img src="<?php echo e(asset(getSetting()->logo)); ?>" alt="" width="50"></a>
        <a href="<?php echo e(route('user.dashboard')); ?>"><img class="logo-inverse" src="<?php echo e(asset(getSetting()->logo)); ?>" alt="" width="50"></a>
    </div>

    <div class="header_right">
        <ul>
            <li class="profile-dropdown">
                <a href="#" class="opts_account" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                    <img src="<?php echo e(asset(Auth::user()->image)); ?>" alt="" style="width: 40px;
                    height: 40px; border-radius: 50px;">
                </a>
                <div class="dropdown-menu dropdown_account drop-down dropdown-menu-end">
                    <div class="channel_my">
                        <div class="profile_link">
                            <img src="<?php echo e(asset(Auth::user()->image)); ?>" alt="" style="width: 40px; height: 40px; border-radius: 50px;">
                            <div class="pd_content">
                                <div class="rhte85">
                                    <h6><?php echo e(Auth::user()->name); ?></h6>
                                </div>
                                <span><?php echo e(Auth::user()->email); ?></span>
                            </div>
                        </div>
                        <a href="<?php echo e(route('user.user.profile')); ?>" class="dp_link_12">View Profile</a>
                    </div>
                    <a href="<?php echo e(route('user.dashboard')); ?>" class="item channel_item">Dashboard</a>
                    <a href="<?php echo e(route('user.order')); ?>" class="item channel_item">My Order</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" style="border: none;
                            background: transparent;" class="item channel_item"> 
                            <span key="t-logout">Sign Out</span>
                        </button>    
                    </form>
                </div>
            </li>
        </ul>
    </div>
</header><?php /**PATH D:\Real Client Project\course_management\resources\views/user/include/header.blade.php ENDPATH**/ ?>