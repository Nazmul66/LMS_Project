

<?php $__env->startSection('order', 'active'); ?>

<?php $__env->startPush('add-css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />

    <style>
        table tr td,
        table tr th {
            text-align: center; /* Horizontal alignment */
            vertical-align: middle; /* Vertical alignment */
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body-content'); ?>

<div class="row">
    <div class="col-lg-12">
        <h2 class="st_title">My Orders</h2>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="_14d25">
            <div class="row">
                <div class="table-responsive">
                    <table class="table mb-0 table-hover" id="datatables">
                        <thead>
                        <tr>
                            <th scope="col">#SL.</th>
                            <th scope="col">Order Id</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Course Name</th>
                            <th scope="col">Total Product</th>
                            <th scope="col">Total Amount</th>
                            <th scope="col">Payment Method</th>
                            <th scope="col">Status</th>
                        </tr>
                        </thead>
    
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $course = App\Models\Course::where('id', $item->course_id)->first();
                                ?>    

                                <tr class="text-center align-middle">
                                    <th scope="row"><?php echo e($row + 1); ?></th>
                                    <td><?php echo e($item->order_id); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td>
                                        <a href="mailto: <?php echo e($item->email); ?>">
                                            <?php echo e($item->email); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($course->title); ?></td>
                                    <td><?php echo e($item->total_product); ?></td>
                                    <td>$<?php echo e($item->total_amount); ?></td>
                                    <td><?php echo e($item->payment_method); ?></td>
                                    <td>
                                        <?php if( $item->status == 1 ): ?>
                                            <span class="text-success">Paid</span>
                                        <?php elseif( $item->status == 2 ): ?>
                                            <span class="text-warning">Pending</span>
                                        <?php else: ?>
                                            <span class="text-danger">Cancel</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('add-js'); ?>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>

    <script>
        let table = new DataTable('#datatables', {
            responsive: true
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Real Client Project\course_management\resources\views/user/pages/order.blade.php ENDPATH**/ ?>