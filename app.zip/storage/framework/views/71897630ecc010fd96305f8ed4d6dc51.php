<section class="page-header">
    <div class="bg-item">
        
        <div class="overlay"></div>
        <div class="shapes">
            
            <div class="shape shape-2"><img src="<?php echo e(asset('frontend/assets/img/shapes/page-header-shape-2.png')); ?>" alt="shape"></div>
            <div class="shape shape-3"><img src="<?php echo e(asset('frontend/assets/img/shapes/page-header-shape-3.png')); ?>" alt="shape"></div>
        </div>
    </div>
    <div class="container">
        <div class="page-header-content">
            <h1 class="title"><?php echo e($title); ?></h1>
            <h4 class="sub-title"><a class="home" href="index.html">Home </a><span class="icon">/</span><a class="inner-page" href="javascript:void();"> <?php echo e($title); ?></a></h4>
        </div>
    </div>
</section><?php /**PATH D:\Real Client Project\course_management\resources\views/frontend/include/breadcrumb.blade.php ENDPATH**/ ?>