<div id="scrollup">
    <button id="scroll-top" class="scroll-to-top">
        <i class="fa-solid fa-arrow-up"></i>
    </button>
</div>